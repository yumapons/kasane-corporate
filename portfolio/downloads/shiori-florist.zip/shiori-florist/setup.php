<?php
if(!defined('ABSPATH'))exit;
add_action('admin_menu',function(){add_theme_page('しおり デモ設定','しおり デモ設定','manage_options','shiori-demo','shiori_setup_screen');});
function shiori_setup_screen(){
 if(!current_user_can('manage_options'))return;
 echo '<div class="wrap"><h1>花屋しおり デモ設定</h1>';
 if(isset($_POST['shiori_create'])){
  check_admin_referer('shiori_create');$created=0;
  foreach(array('home'=>'ホーム','flowers'=>'花と予算','order'=>'ご注文の相談','shop'=>'お店について')as $slug=>$title){if(get_page_by_path($slug))continue;$id=wp_insert_post(array('post_type'=>'page','post_status'=>'draft','post_name'=>$slug,'post_title'=>$title,'post_content'=>'<!-- wp:html -->'.shiori_markup($slug).'<!-- /wp:html -->'),true);if(!is_wp_error($id))$created++;}
  echo '<div class="notice notice-success"><p>'.esc_html($created).'件の下書きを作成しました。既存ページは変更していません。</p></div>';
 }
 echo '<p>架空の花店のデモ4ページを下書きで作成します。同じスラッグがある場合はスキップします。公開、サイト名、表示設定は変更しません。</p><p>固定ページで文章・営業情報を確認して公開し、設定 → 表示設定で「ホーム」を固定ホームページに指定してください。このテーマは自主制作デモのためnoindexです。実運用前に解除と内容の差し替えが必要です。</p><form method="post">';wp_nonce_field('shiori_create');submit_button('デモ4ページの下書きを作成','primary','shiori_create');echo '</form></div>';
}
