<?php
if(!defined('ABSPATH'))exit;
add_action('after_setup_theme',function(){add_theme_support('title-tag');add_theme_support('responsive-embeds');add_theme_support('html5',array('style','script'));});
add_action('wp_enqueue_scripts',function(){wp_enqueue_style('shiori',get_stylesheet_uri(),array(),'1.0.0');wp_enqueue_script('shiori',get_template_directory_uri().'/app.js',array(),'1.0.0',true);});
function shiori_markup($key){$name=in_array($key,array('header','footer'),true)?'chrome.json':'content.json';$all=json_decode(file_get_contents(get_template_directory().'/'.$name),true);$html=isset($all[$key])?$all[$key]:'';$html=str_replace('assets/',esc_url(trailingslashit(get_template_directory_uri()).'assets/'),$html);foreach(array('index'=>'','flowers'=>'flowers/','order'=>'order/','shop'=>'shop/')as $a=>$b)$html=str_replace($a.'.html',esc_url(home_url('/'.$b)),$html);return $html;}
add_action('wp_head',function(){echo '<meta name="robots" content="noindex,nofollow">';});
require_once get_template_directory().'/setup.php';
