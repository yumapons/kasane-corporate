<?php
if (!defined('ABSPATH')) exit;
add_action('after_setup_theme',function(){add_theme_support('title-tag');add_theme_support('html5',array('style','script','search-form'));});
add_action('wp_enqueue_scripts',function(){wp_enqueue_style('machi-main',get_stylesheet_uri(),array(),'1.0.0');wp_enqueue_script('machi-main',get_template_directory_uri().'/app.js',array(),'1.0.0',true);});
function machi_markup($key){$source=in_array($key,array('header','footer'),true)?'chrome.json':'content.json';$data=json_decode(file_get_contents(get_template_directory().'/'.$source),true);$html=isset($data[$key])?$data[$key]:'';$html=str_replace('assets/',esc_url(trailingslashit(get_template_directory_uri()).'assets/'),$html);foreach(array('index'=>'','services'=>'services/','pricing'=>'pricing/','contact'=>'contact/') as $from=>$to){$html=str_replace($from.'.html',esc_url(home_url('/'.$to)),$html);}return $html;}
add_action('wp_head',function(){echo '<meta name="robots" content="noindex,nofollow">';});
require_once get_template_directory().'/setup.php';
