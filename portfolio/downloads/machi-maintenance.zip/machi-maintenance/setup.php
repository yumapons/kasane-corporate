<?php
if (!defined('ABSPATH')) exit;
add_action('admin_menu',function(){add_theme_page('まちの水道 デモ設定','まちの水道 デモ設定','manage_options','machi-demo','machi_setup_screen');});
function machi_setup_screen(){
 if(!current_user_can('manage_options'))return;
 echo '<div class="wrap"><h1>まちの水道メンテ / デモ設定</h1>';
 if(isset($_POST['machi_create'])){
  check_admin_referer('machi_create');$created=0;$errors=0;
  foreach(array('home'=>'ホーム','services'=>'できること','pricing'=>'料金について','contact'=>'相談メモ') as $slug=>$title){
   if(get_page_by_path($slug))continue;
   $id=wp_insert_post(array('post_type'=>'page','post_status'=>'draft','post_name'=>$slug,'post_title'=>$title,'post_content'=>'<!-- wp:html -->'.machi_markup($slug).'<!-- /wp:html -->'),true);
   if(is_wp_error($id)){$errors++;}else{$created++;}
  }
  echo '<div class="notice notice-success"><p>'.esc_html($created).'件の下書きを作成しました。既存ページは変更していません。</p></div>';
  if($errors)echo '<div class="notice notice-error"><p>作成できないページがありました。固定ページ一覧を確認してください。</p></div>';
 }
 echo '<p>架空の水道修理事業者を題材にした自主制作です。デモ4ページを下書きとして作成します。同じスラッグがある場合は作成せず、既存の内容を変更しません。サイト名・表示設定・検索設定は変更しません。</p><p>固定ページを確認して公開した後、設定 → 表示設定で「ホーム」をホームページに選択してください。文章はカスタムHTMLブロックで編集します。フォームは相談メモ作成のみで外部送信しません。</p><form method="post">';
 wp_nonce_field('machi_create');submit_button('デモ4ページの下書きを作成','primary','machi_create');echo '</form></div>';
}
