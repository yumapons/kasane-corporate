<?php
if(!defined('ABSPATH'))exit;
add_action('after_setup_theme',function(){add_theme_support('title-tag');add_theme_support('responsive-embeds');add_theme_support('html5',array('style','script'));});
add_action('wp_enqueue_scripts',function(){wp_enqueue_style('komugi-main',get_stylesheet_uri(),array(),'1.0.0');wp_enqueue_script('komugi-main',get_template_directory_uri().'/app.js',array(),'1.0.0',true);});
function komugi_markup($key){$name=in_array($key,array('header','footer'),true)?'chrome.json':'content.json';$data=json_decode(file_get_contents(get_template_directory().'/'.$name),true);$out=isset($data[$key])?$data[$key]:'';$out=str_replace('assets/',esc_url(trailingslashit(get_template_directory_uri()).'assets/'),$out);foreach(array('index'=>'','bread'=>'bread/','visit'=>'visit/','reserve'=>'reserve/')as$from=>$to){$out=str_replace($from.'.html',esc_url(home_url('/'.$to)),$out);}return $out;}
add_action('wp_head',function(){echo '<meta name="robots" content="noindex,nofollow">';});
require_once get_template_directory().'/setup.php';
