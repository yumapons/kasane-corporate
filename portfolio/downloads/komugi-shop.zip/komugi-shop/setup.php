<?php
if(!defined('ABSPATH'))exit;
add_action('admin_menu',function(){add_theme_page('こむぎと、デモ設定','こむぎと、デモ設定','manage_options','komugi-demo','komugi_setup_screen');});
function komugi_setup_screen(){
 if(!current_user_can('manage_options'))return;
 echo '<div class="wrap"><h1>こむぎと、デモ設定</h1>';
 if(isset($_POST['komugi_create'])){check_admin_referer('komugi_create');$count=0;foreach(array('home'=>'ホーム','bread'=>'パンと焼き時間','visit'=>'お店のこと','reserve'=>'取り置きメモ')as$slug=>$title){if(get_page_by_path($slug))continue;$id=wp_insert_post(array('post_type'=>'page','post_status'=>'draft','post_name'=>$slug,'post_title'=>$title,'post_content'=>'<!-- wp:html -->'.komugi_markup($slug).'<!-- /wp:html -->'),true);if(!is_wp_error($id))$count++;}echo '<div class="notice notice-success"><p>'.esc_html($count).'件の下書きを作成しました。</p></div>';}
 echo '<p>架空店舗のデモ4ページを下書きで作成します。同じスラッグの既存ページは変更しません。内容を確認・公開した後、設定 → 表示設定で「ホーム」をホームページに指定してください。サイト名と表示設定は自動変更しません。</p><p>本文はカスタムHTMLブロックです。取り置きフォームはメモ作成のみで外部送信しません。商品・価格・店舗情報は架空設定です。</p><form method="post">';wp_nonce_field('komugi_create');submit_button('デモページの下書きを作成','primary','komugi_create');echo '</form></div>';
}
