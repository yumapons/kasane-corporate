<?php
/**
 * Plugin Name: YF 制作実績と制作相談
 * Description: 自主制作の業種別サイト3件と、管理者が有効化した場合の制作相談フォーム。
 * Version: 1.0.0
 * Requires PHP: 8.0
 * License: GPL-2.0-or-later
 */
if (!defined('ABSPATH')) exit;
function yfp_projects() {
    return array(
      'bakery'=>array('name'=>'こむぎと、','industry'=>'パン店','description'=>'焼き上がり時刻と商品案内から、取り置きの確認へ。毎日の営業に必要な情報を先に読める構成。','scope'=>'商品案内・営業情報・取り置きデモ・WordPressテーマ','image'=>'bakery.png','url'=>'https://yumapons.github.io/kasane-corporate/portfolio/bakery/'),
      'florist'=>array('name'=>'花屋 しおり','industry'=>'花屋','description'=>'贈る目的、予算、受取日。注文前に決めたいことを整理し、花束選びから相談につなぐ構成。','scope'=>'用途別案内・参考料金・注文デモ・WordPressテーマ','image'=>'florist.png','url'=>'https://yumapons.github.io/kasane-corporate/portfolio/florist/'),
      'repair'=>array('name'=>'まちの水道メンテ','industry'=>'水まわり修理','description'=>'症状に合う作業と料金の内訳を確認。追加費用の条件まで示して、相談前の不安を減らす構成。','scope'=>'作業内容・料金表・相談メモ・WordPressテーマ','image'=>'repair.png','url'=>'https://yumapons.github.io/kasane-corporate/portfolio/repair/')
    );
}
add_action('wp_enqueue_scripts',function(){wp_register_style('yfp',plugins_url('portfolio.css',__FILE__),array(),'1.0.0');});
add_shortcode('yf_portfolio',function(){
    wp_enqueue_style('yfp'); $settings=get_option('yfp_settings',array()); ob_start(); ?>
    <section class="yfp" aria-label="自主制作のWebサイト一覧"><div class="yfp-title"><p>YUMA FUJITA / WEB DESIGN</p><h2>お店の仕事に合わせて、<br>サイトをつくる。</h2><p>商品を選ぶ、来店の準備をする、作業を相談する。<br>お客様が知りたい順番から考えた、業種別の制作例です。</p></div>
    <?php $i=0; foreach(yfp_projects() as $key=>$project): $i++; $url=$settings[$key.'_url']??$project['url']; ?>
    <article class="yfp-work"><div class="yfp-visual"><img src="<?php echo esc_url(plugins_url('assets/'.$project['image'],__FILE__)); ?>" alt="<?php echo esc_attr($project['name'].'のトップページ'); ?>" loading="lazy"></div><div class="yfp-description"><p class="yfp-meta"><?php echo esc_html(sprintf('%02d / %s',$i,$project['industry'])); ?></p><h3><?php echo esc_html($project['name']); ?></h3><p><?php echo esc_html($project['description']); ?></p><p class="yfp-scope"><?php echo esc_html($project['scope']); ?></p><p class="yfp-small">自主制作 / 架空の店舗・事業者</p><?php if($url): ?><a class="yfp-link" href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener">制作例を見る <span aria-hidden="true">↗</span></a><?php endif; ?></div></article>
    <?php endforeach; ?>
    <section class="yfp-offer"><h3>制作のご相談</h3><p>店舗・小規模事業者向けのWordPressサイトを制作します。商品や料金、営業情報を整理し、スマートフォンから読みやすく仕上げます。</p><dl><div><dt>参考価格</dt><dd>5ページ 55,000円（税込）から</dd></div><div><dt>制作期間</dt><dd>原稿・画像と仕様の確定後、初稿まで約2週間</dd></div><div><dt>含むもの</dt><dd>構成・デザイン・WordPressテーマ実装・スマホ対応・修正2回</dd></div><div><dt>別途相談</dt><dd>ドメイン・サーバー・有料ライセンス・予約や決済・メール配信・運用保守</dd></div></dl><p><a class="yfp-link" href="https://crowdworks.jp/public/employees/7324174">クラウドワークスのプロフィールから相談する ↗</a></p><p class="yfp-small">上記3件は受託・施工・営業実績ではありません。画像は生成した架空のイメージまたは独自の図解です。制作例の注文・問い合わせはデモです。</p></section></section>
    <?php return ob_get_clean();
});
function yfp_sanitize_settings($input){
    $result=array(); foreach(yfp_projects() as $key=>$project){$url=isset($input[$key.'_url'])?esc_url_raw($input[$key.'_url']):'';$result[$key.'_url']=$url&&wp_http_validate_url($url)?$url:'';}
    $result['email']=sanitize_email($input['email']??'');$result['enabled']=!empty($input['enabled'])&&is_email($result['email'])?1:0;return $result;
}
add_action('admin_init',function(){register_setting('yfp','yfp_settings',array('type'=>'array','sanitize_callback'=>'yfp_sanitize_settings','default'=>array()));});
add_action('admin_menu',function(){add_options_page('YF 制作実績','YF 制作実績','manage_options','yfp','yfp_settings_page');});
function yfp_settings_page(){if(!current_user_can('manage_options'))return;$s=get_option('yfp_settings',array()); ?>
<div class="wrap"><h1>YF 制作実績</h1><p>固定ページに <code>[yf_portfolio]</code> を置くと実績一覧が表示されます。<code>[yf_project_enquiry]</code> で制作相談フォームを追加できます。公開・送信は自動では開始しません。</p><form action="options.php" method="post"><?php settings_fields('yfp'); ?><table class="form-table"><?php foreach(yfp_projects() as $key=>$p): ?><tr><th><label for="yfp-<?php echo esc_attr($key); ?>"><?php echo esc_html($p['name']); ?> 公開デモURL</label></th><td><input class="regular-text" id="yfp-<?php echo esc_attr($key); ?>" type="url" name="yfp_settings[<?php echo esc_attr($key); ?>_url]" value="<?php echo esc_attr($s[$key.'_url']??$p['url']); ?>"></td></tr><?php endforeach; ?><tr><th><label for="yfp-email">制作相談の受信先</label></th><td><input id="yfp-email" class="regular-text" type="email" name="yfp_settings[email]" value="<?php echo esc_attr($s['email']??''); ?>"><p>自分が管理するメールアドレスを指定。送信テストとプライバシー表記を確認してから有効化してください。</p></td></tr><tr><th>フォーム送信</th><td><label><input type="checkbox" name="yfp_settings[enabled]" value="1" <?php checked(!empty($s['enabled'])); ?>>制作相談メールの送信を有効にする</label><p>有効化するまでフォームは表示しません。送信内容はWordPressのDBには保存しません。メール配信の到達はサーバー設定に依存します。</p></td></tr></table><?php submit_button(); ?></form></div>
<?php }
add_shortcode('yf_project_enquiry',function(){ $s=get_option('yfp_settings',array());if(empty($s['enabled'])||empty($s['email']))return '';wp_enqueue_style('yfp');ob_start(); ?>
<section class="yfp yfp-enquiry"><h2>制作について相談する</h2><?php if(($_GET['yfp_notice']??'')==='received'): ?><p role="status">ご相談を受け付けました。入力いただいたメールアドレスへの返信をお待ちください。</p><?php endif; ?><p>お預かりした情報は、制作のご相談への返信に使用します。入力内容は受信担当者へメールで送られます。</p><form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post"><input type="hidden" name="action" value="yfp_enquiry"><?php wp_nonce_field('yfp_enquiry','yfp_nonce'); ?><input type="hidden" name="started" value="<?php echo esc_attr(time()); ?>"><div class="yfp-honey" aria-hidden="true"><label>この欄は空欄にしてください<input name="website_confirm" tabindex="-1" autocomplete="off"></label></div><label>お名前（必須）<input name="name" required maxlength="80" autocomplete="name"></label><label>メールアドレス（必須）<input name="email" type="email" required maxlength="254" autocomplete="email"></label><label>ご相談内容（必須）<textarea name="message" required minlength="20" maxlength="4000" rows="7" placeholder="業種、希望ページ数、公開したい時期など、決まっていることをお知らせください。"></textarea></label><label class="yfp-consent"><input name="consent" type="checkbox" value="1" required>制作相談への返信を目的とした情報の利用に同意します。</label><button type="submit">制作相談を送信する →</button><p class="yfp-small">パスワードや機密情報は入力しないでください。送信だけで契約は成立しません。</p></form></section>
<?php return ob_get_clean(); });
add_action('admin_post_nopriv_yfp_enquiry','yfp_submit_enquiry');add_action('admin_post_yfp_enquiry','yfp_submit_enquiry');
function yfp_submit_enquiry(){
    if(($_SERVER['REQUEST_METHOD']??'')!=='POST')wp_die('この操作にはPOSTを使用してください。','',array('response'=>405));
    $s=get_option('yfp_settings',array());if(empty($s['enabled'])||!is_email($s['email']??''))wp_die('現在、相談フォームを受け付けていません。','',array('response'=>503));
    if(!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['yfp_nonce']??'')),'yfp_enquiry'))wp_die('確認の有効期限が切れました。元のページを開き直してください。','',array('response'=>403));
    if(!empty($_POST['website_confirm'])||time()-absint($_POST['started']??0)<3)wp_die('入力内容をご確認ください。','',array('response'=>400));
    $name=sanitize_text_field(wp_unslash($_POST['name']??''));$email=sanitize_email(wp_unslash($_POST['email']??''));$message=sanitize_textarea_field(wp_unslash($_POST['message']??''));
    if(!$name||strlen($name)>320||!is_email($email)||strlen($message)<20||strlen($message)>16000||($_POST['consent']??'')!=='1')wp_die('お名前、メールアドレス、ご相談内容、同意欄をご確認ください。','',array('response'=>400));
    $key='yfp_'.hash_hmac('sha256',$_SERVER['REMOTE_ADDR']??'unknown',wp_salt('nonce'));if(get_transient($key))wp_die('続けて送信する場合は、しばらく時間をおいてください。','',array('response'=>429));
    set_transient($key,1,MINUTE_IN_SECONDS);
    $ok=wp_mail($s['email'],'Webサイト制作のご相談',"お名前：".$name."\n返信先：".$email."\n\n".$message,array('Reply-To: '.$email));
    if(!$ok){delete_transient($key);wp_die('メールを送信できませんでした。時間をおいて再度お試しください。','',array('response'=>502));}
    wp_safe_redirect(add_query_arg('yfp_notice','received',wp_get_referer()?:home_url('/')),303);exit;
}
